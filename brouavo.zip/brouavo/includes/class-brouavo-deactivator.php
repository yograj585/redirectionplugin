<?php
class Brouavo_Deactivator {
    public static function deactivate() {
        // Clean up if needed
    }
}