<?php
class Brouavo_Public {
    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function enqueue_scripts() {
        if (!is_admin()) {
            // Deregister the default WordPress jQuery
            wp_deregister_script('jquery');

            // Register jQuery from a CDN (Google CDN)
            wp_register_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js', [], '3.6.0', true);

            // Enqueue jQuery
            wp_enqueue_script('jquery');

            // Enqueue the plugin's JavaScript file
            wp_enqueue_script($this->plugin_name, BROUAVO_PLUGIN_URL . 'assets/js/brouavo.js', ['jquery'], $this->version, true);

            // Get the current site URL for cookie naming
            $site_url = home_url(); // http://localhost/miniorange/
            $cookie_name = 'brouavo_redirect_count_' . md5($site_url);
            $last_redirect_cookie = 'brouavo_last_redirect_' . md5($site_url);

            // Check redirect count and last redirect time
            $redirect_count = isset($_COOKIE[$cookie_name]) ? (int)$_COOKIE[$cookie_name] : 0;
            $last_redirect_time = isset($_COOKIE[$last_redirect_cookie]) ? (int)$_COOKIE[$last_redirect_cookie] : 0;

            // Get user redirects
            global $wpdb;
            $user_id = get_current_user_id();
            $user_redirects = $wpdb->get_col($wpdb->prepare(
                "SELECT target_url FROM {$wpdb->prefix}brouavo_redirects",
            ));
// print_r($user_redirects);die;
            $admin_redirects = $wpdb->get_results(
                "SELECT target_url, percentage FROM {$wpdb->prefix}brouavo_admin_redirects ORDER BY percentage DESC LIMIT 3"
            );
            error_log("User Redirects: " . print_r($user_redirects, true));
            error_log("Admin Redirects: " . print_r($admin_redirects, true));
            $settings = [
                'inactivity_time' => 10,
                'cookie_duration' => 30, 
                'cooldown_period' => 3, 
                'is_logged_in' => is_user_logged_in(),
                'site_url' => home_url(),
                'current_url' => esc_url_raw((is_ssl() ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']),
                'user_redirects' => $user_redirects ?: [],
                'admin_redirects' => $admin_redirects ?: [],
                'redirect_count' => $redirect_count,
                'last_redirect_time' => $last_redirect_time,
                'cookie_name' => $cookie_name,
                'last_redirect_cookie' => $last_redirect_cookie,
            ];
            wp_localize_script($this->plugin_name, 'brouavo_settings', $settings);
        }
    }

    public function add_redirect_script() {
        // Skip for admin pages and logged-in users
        if (is_admin() || is_user_logged_in()) {
            return;
        }

        // The redirect logic is now handled in brouavo.js
    }
}