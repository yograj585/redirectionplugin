<?php
class Brouavo {
    protected $loader;
    protected $plugin_name;
    protected $version;

    public function __construct() {
        $this->plugin_name = 'brouavo';
        $this->version = BROUAVO_VERSION;

        $this->load_dependencies();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    private function load_dependencies() {
        require_once BROUAVO_PLUGIN_DIR . 'includes/class-brouavo-activator.php';
        require_once BROUAVO_PLUGIN_DIR . 'includes/class-brouavo-deactivator.php';
        require_once BROUAVO_PLUGIN_DIR . 'includes/class-brouavo-admin.php';
        require_once BROUAVO_PLUGIN_DIR . 'includes/class-brouavo-public.php';
    }

    private function define_admin_hooks() {
        $plugin_admin = new Brouavo_Admin($this->get_plugin_name(), $this->get_version());
        add_action('admin_menu', [$plugin_admin, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$plugin_admin, 'enqueue_styles']);
        add_action('admin_enqueue_scripts', [$plugin_admin, 'enqueue_scripts']);
    }

    private function define_public_hooks() {
        $plugin_public = new Brouavo_Public($this->get_plugin_name(), $this->get_version());
        add_action('wp_enqueue_scripts', [$plugin_public, 'enqueue_scripts']);
        add_action('wp_footer', [$plugin_public, 'add_redirect_script']);
    }

    public function run() {
        register_activation_hook(__FILE__, ['Brouavo_Activator', 'activate']);
        register_deactivation_hook(__FILE__, ['Brouavo_Deactivator', 'deactivate']);
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_version() {
        return $this->version;
    }
}