<?php
class Brouavo_Admin {
    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function add_admin_menu() {
        add_menu_page(
            __('Brouavo', 'brouavo'),
            __('Brouavo', 'brouavo'),
            'manage_options',
            'brouavo',
            [$this, 'admin_page_display'],
            'dashicons-admin-links',
            80
        );
    }

    public function admin_page_display() {
        $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'configurations';
        ?>
        <div class="wrap">
            <h1><?php _e('Brouavo Settings', 'brouavo'); ?></h1>
            <h2 class="nav-tab-wrapper">
                <a href="?page=brouavo&tab=configurations" class="nav-tab <?php echo $active_tab == 'configurations' ? 'nav-tab-active' : ''; ?>"><?php _e('Configurations', 'brouavo'); ?></a>
                <a href="?page=brouavo&tab=paypal" class="nav-tab <?php echo $active_tab == 'paypal' ? 'nav-tab-active' : ''; ?>"><?php _e('PayPal', 'brouavo'); ?></a>
                <a href="?page=brouavo&tab=uploads" class="nav-tab <?php echo $active_tab == 'uploads' ? 'nav-tab-active' : ''; ?>"><?php _e('Uploads', 'brouavo'); ?></a>
                <a href="?page=brouavo&tab=support" class="nav-tab <?php echo $active_tab == 'support' ? 'nav-tab-active' : ''; ?>"><?php _e('Support', 'brouavo'); ?></a>
                <a href="?page=brouavo&tab=useful-links" class="nav-tab <?php echo $active_tab == 'useful-links' ? 'nav-tab-active' : ''; ?>"><?php _e('Useful Links', 'brouavo'); ?></a>
                <a href="?page=brouavo&tab=documentation" class="nav-tab <?php echo $active_tab == 'documentation' ? 'nav-tab-active' : ''; ?>"><?php _e('Documentation', 'brouavo'); ?></a>
                <a href="?page=brouavo&tab=boost-traffic" class="nav-tab <?php echo $active_tab == 'boost-traffic' ? 'nav-tab-active' : ''; ?>"><?php _e('Boost Your Traffic', 'brouavo'); ?></a>
                <a href="?page=brouavo&tab=suggestions" class="nav-tab <?php echo $active_tab == 'suggestions' ? 'nav-tab-active' : ''; ?>"><?php _e('Suggestions', 'brouavo'); ?></a>
            </h2>
            <?php
            switch ($active_tab) {
                case 'configurations':
                    include BROUAVO_PLUGIN_DIR . 'admin/templates/admin-tabs/configurations.php';
                    break;
                case 'paypal':
                    include BROUAVO_PLUGIN_DIR . 'admin/templates/admin-tabs/paypal.php';
                    break;
                case 'uploads':
                    include BROUAVO_PLUGIN_DIR . 'admin/templates/admin-tabs/uploads.php';
                    break;
                case 'support':
                    include BROUAVO_PLUGIN_DIR . 'admin/templates/admin-tabs/support.php';
                    break;
                case 'useful-links':
                    include BROUAVO_PLUGIN_DIR . 'admin/templates/admin-tabs/useful-links.php';
                    break;
                case 'documentation':
                    include BROUAVO_PLUGIN_DIR . 'admin/templates/admin-tabs/documentation.php';
                    break;
                case 'boost-traffic':
                    include BROUAVO_PLUGIN_DIR . 'admin/templates/admin-tabs/boost-traffic.php';
                    break;
                case 'suggestions':
                    include BROUAVO_PLUGIN_DIR . 'admin/templates/admin-tabs/suggestions.php';
                    break;
            }
            ?>
        </div>
        <?php
    }

    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name, BROUAVO_PLUGIN_URL . 'assets/css/brouavo.css', [], $this->version, 'all');
    }

    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name, BROUAVO_PLUGIN_URL . 'assets/js/brouavo.js', ['jquery'], $this->version, true);
    }
}