<?php
class Brouavo_Activator {
    public static function activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'brouavo_redirects';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            redirect_type varchar(20) NOT NULL,
            source_url text NOT NULL,
            target_url text NOT NULL,
            redirect_count bigint(20) DEFAULT 0,
            last_redirect datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        // Create table for admin redirects
        $admin_table = $wpdb->prefix . 'brouavo_admin_redirects';
        $sql_admin = "CREATE TABLE $admin_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            target_url text NOT NULL,
            percentage int(3) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        dbDelta($sql_admin);

        // Create table for user stats
        $stats_table = $wpdb->prefix . 'brouavo_stats';
        $sql_stats = "CREATE TABLE $stats_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            website_url text NOT NULL,
            redirect_count bigint(20) DEFAULT 0,
            period varchar(20) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        dbDelta($sql_stats);
    }
}