<?php
if (!current_user_can('manage_options')) {
    return;
}

$traffic_tips = get_option('brouavo_traffic_tips', '');

if (isset($_POST['brouavo_save_traffic_tips'])) {
    update_option('brouavo_traffic_tips', wp_kses_post($_POST['traffic_tips']));
    echo '<div class="updated"><p>' . __('Traffic tips saved.', 'brouavo') . '</p></div>';
}
?>

<div class="brouavo-boost-traffic">
    <h2><?php _e('Boost Your Traffic', 'brouavo'); ?></h2>
    <?php if (current_user_can('administrator')) : ?>
        <form method="post" action="">
            <p>
                <label for="traffic_tips"><?php _e('Traffic Tips Content', 'brouavo'); ?></label><br>
                <?php
                wp_editor(
                    $traffic_tips,
                    'traffic_tips',
                    [
                        'textarea_name' => 'traffic_tips',
                        'textarea_rows' => 10,
                    ]
                );
                ?>
            </p>
            <p>
                <input type="submit" name="brouavo_save_traffic_tips" class="button button-primary" value="<?php _e('Save Tips', 'brouavo'); ?>">
            </p>
        </form>
    <?php else : ?>
        <div class="traffic-tips-content">
            <?php echo wp_kses_post($traffic_tips); ?>
        </div>
    <?php endif; ?>
</div>