<?php
if (!current_user_can('manage_options')) {
    return;
}

$whatsapp_group_link = get_option('brouavo_whatsapp_group_link', 'https://chat.whatsapp.com/yourgroup');

if (isset($_POST['brouavo_save_suggestions'])) {
    update_option('brouavo_whatsapp_group_link', esc_url_raw($_POST['whatsapp_group_link']));
    echo '<div class="updated"><p>' . __('Suggestions settings saved.', 'brouavo') . '</p></div>';
}
?>

<div class="brouavo-suggestions">
    <h2><?php _e('Suggestions', 'brouavo'); ?></h2>
    <?php if (current_user_can('administrator')) : ?>
        <form method="post" action="">
            <p>
                <label for="whatsapp_group_link"><?php _e('WhatsApp Group Link for Suggestions', 'brouavo'); ?></label><br>
                <input type="url" name="whatsapp_group_link" id="whatsapp_group_link" value="<?php echo esc_attr($whatsapp_group_link); ?>" class="regular-text">
            </p>
            <p>
                <input type="submit" name="brouavo_save_suggestions" class="button button-primary" value="<?php _e('Save Settings', 'brouavo'); ?>">
            </p>
        </form>
    <?php endif; ?>
    <p>
        <?php _e('Have suggestions for Brouavo? Join our WhatsApp group to share your ideas!', 'brouavo'); ?><br>
        <a href="<?php echo esc_url($whatsapp_group_link); ?>" target="_blank" class="button"><?php _e('Join WhatsApp Group', 'brouavo'); ?></a>
    </p>
</div>