<?php
if (!current_user_can('manage_options')) {
    return;
}

$documentation_content = get_option('brouavo_documentation_content', '');

if (isset($_POST['brouavo_save_documentation'])) {
    update_option('brouavo_documentation_content', wp_kses_post($_POST['documentation_content']));
    echo '<div class="updated"><p>' . __('Documentation saved.', 'brouavo') . '</p></div>';
}
?>

<div class="brouavo-documentation">
    <h2><?php _e('Documentation', 'brouavo'); ?></h2>
    <?php if (current_user_can('administrator')) : ?>
        <form method="post" action="">
            <p>
                <label for="documentation_content"><?php _e('Documentation Content', 'brouavo'); ?></label><br>
                <?php
                wp_editor(
                    $documentation_content,
                    'documentation_content',
                    [
                        'textarea_name' => 'documentation_content',
                        'textarea_rows' => 10,
                    ]
                );
                ?>
            </p>
            <p>
                <input type="submit" name="brouavo_save_documentation" class="button button-primary" value="<?php _e('Save Documentation', 'brouavo'); ?>">
            </p>
        </form>
    <?php else : ?>
        <div class="documentation-content">
            <?php echo wp_kses_post($documentation_content); ?>
        </div>
    <?php endif; ?>
</div>