<?php
if (!current_user_can('manage_options')) {
    return;
}

$useful_links = get_option('brouavo_useful_links', []);

if (isset($_POST['brouavo_save_useful_links'])) {
    $links = [];
    if (!empty($_POST['link_titles']) && !empty($_POST['link_urls'])) {
        $titles = array_map('sanitize_text_field', $_POST['link_titles']);
        $urls = array_map('esc_url_raw', $_POST['link_urls']);
        for ($i = 0; $i < count($titles); $i++) {
            if (!empty($titles[$i]) && !empty($urls[$i])) {
                $links[] = ['title' => $titles[$i], 'url' => $urls[$i]];
            }
        }
    }
    update_option('brouavo_useful_links', $links);
    echo '<div class="updated"><p>' . __('Useful links saved.', 'brouavo') . '</p></div>';
}
?>

<div class="brouavo-useful-links">
    <h2><?php _e('Useful Links', 'brouavo'); ?></h2>
    <form method="post" action="">
        <div id="useful-links-container">
            <?php if (!empty($useful_links)) : ?>
                <?php foreach ($useful_links as $index => $link) : ?>
                    <div class="useful-link-row">
                        <p>
                            <label><?php _e('Link Title', 'brouavo'); ?></label><br>
                            <input type="text" name="link_titles[]" value="<?php echo esc_attr($link['title']); ?>" class="regular-text">
                        </p>
                        <p>
                            <label><?php _e('Link URL', 'brouavo'); ?></label><br>
                            <input type="url" name="link_urls[]" value="<?php echo esc_attr($link['url']); ?>" class="regular-text">
                        </p>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="useful-link-row">
                    <p>
                        <label><?php _e('Link Title', 'brouavo'); ?></label><br>
                        <input type="text" name="link_titles[]" class="regular-text">
                    </p>
                    <p>
                        <label><?php _e('Link URL', 'brouavo'); ?></label><br>
                        <input type="url" name="link_urls[]" class="regular-text">
                    </p>
                </div>
            <?php endif; ?>
        </div>
        <p>
            <button type="button" class="button" id="add-useful-link"><?php _e('Add Another Link', 'brouavo'); ?></button>
        </p>
        <p>
            <input type="submit" name="brouavo_save_useful_links" class="button button-primary" value="<?php _e('Save Links', 'brouavo'); ?>">
        </p>
    </form>

    <script>
        jQuery(document).ready(function($) {
            $('#add-useful-link').on('click', function() {
                var newRow = '<div class="useful-link-row">' +
                    '<p><label><?php _e('Link Title', 'brouavo'); ?></label><br>' +
                    '<input type="text" name="link_titles[]" class="regular-text"></p>' +
                    '<p><label><?php _e('Link URL', 'brouavo'); ?></label><br>' +
                    '<input type="url" name="link_urls[]" class="regular-text"></p>' +
                    '</div>';
                $('#useful-links-container').append(newRow);
            });
        });
    </script>
</div>