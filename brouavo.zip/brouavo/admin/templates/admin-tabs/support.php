<?php
if (!current_user_can('manage_options')) {
    return;
}

$support_email = get_option('brouavo_support_email', 'support@brouavo.com');
$whatsapp_link = get_option('brouavo_whatsapp_link', 'https://wa.me/1234567890');

if (isset($_POST['brouavo_save_support'])) {
    update_option('brouavo_support_email', sanitize_email($_POST['support_email']));
    update_option('brouavo_whatsapp_link', esc_url_raw($_POST['whatsapp_link']));
    echo '<div class="updated"><p>' . __('Support settings saved.', 'brouavo') . '</p></div>';
}
?>

<div class="brouavo-support">
    <h2><?php _e('Support', 'brouavo'); ?></h2>
    <form method="post" action="">
        <p>
            <label for="support_email"><?php _e('Support Email', 'brouavo'); ?></label><br>
            <input type="email" name="support_email" id="support_email" value="<?php echo esc_attr($support_email); ?>" class="regular-text">
        </p>
        <p>
            <label for="whatsapp_link"><?php _e('WhatsApp Support Link', 'brouavo'); ?></label><br>
            <input type="url" name="whatsapp_link" id="whatsapp_link" value="<?php echo esc_attr($whatsapp_link); ?>" class="regular-text">
        </p>
        <p>
            <input type="submit" name="brouavo_save_support" class="button button-primary" value="<?php _e('Save Support Settings', 'brouavo'); ?>">
        </p>
    </form>

    <h3><?php _e('Share Brouavo', 'brouavo'); ?></h3>
    <div class="brouavo-social-buttons">
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode('https://brouavo.com'); ?>" target="_blank" class="button"><?php _e('Share on Facebook', 'brouavo'); ?></a>
        <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode('https://brouavo.com'); ?>&text=<?php echo urlencode('Check out Brouavo!'); ?>" target="_blank" class="button"><?php _e('Share on X', 'brouavo'); ?></a>
        <a href="https://www.tiktok.com/share?url=<?php echo urlencode('https://brouavo.com'); ?>" target="_blank" class="button"><?php _e('Share on TikTok', 'brouavo'); ?></a>
        <a href="<?php echo esc_url($whatsapp_link); ?>" target="_blank" class="button"><?php _e('Contact via WhatsApp', 'brouavo'); ?></a>
    </div>

    <h3><?php _e('Need Help?', 'brouavo'); ?></h3>
    <p><?php printf(__('Email us at <a href="mailto:%s">%s</a> for support.', 'brouavo'), esc_attr($support_email), esc_html($support_email)); ?></p>
</div>