<?php
if (!current_user_can('manage_options')) {
    return;
}

if (isset($_POST['brouavo_upload_image'])) {
    if (!empty($_FILES['image']['name'])) {
        $file = $_FILES['image'];
        $upload = wp_handle_upload($file, ['test_form' => false]);
        if (isset($upload['url'])) {
            $uploads = get_option('brouavo_uploads', []);
            $uploads[] = [
                'url' => $upload['url'],
                'date' => current_time('mysql'),
            ];
            update_option('brouavo_uploads', $uploads);
            echo '<div class="updated"><p>' . __('Image uploaded successfully.', 'brouavo') . '</p></div>';
        }
    }
}

$uploads = get_option('brouavo_uploads', []);
?>

<div class="brouavo-uploads">
    <h2><?php _e('Upload Images', 'brouavo'); ?></h2>
    <form method="post" enctype="multipart/form-data">
        <p>
            <label for="image"><?php _e('Select Image', 'brouavo'); ?></label><br>
            <input type="file" name="image" id="image" accept="image/*" required>
        </p>
        <p>
            <input type="submit" name="brouavo_upload_image" class="button button-primary" value="<?php _e('Upload Image', 'brouavo'); ?>">
        </p>
    </form>

    <h2><?php _e('Uploaded Images', 'brouavo'); ?></h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th><?php _e('Image', 'brouavo'); ?></th>
                <th><?php _e('Upload Date', 'brouavo'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($uploads)) : ?>
                <?php foreach ($uploads as $upload) : ?>
                    <tr>
                        <td><img src="<?php echo esc_url($upload['url']); ?>" width="100"></td>
                        <td><?php echo esc_html($upload['date']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="2"><?php _e('No images uploaded yet.', 'brouavo'); ?></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>