<?php
if (!current_user_can('manage_options')) {
    return;
}

global $wpdb;

if (isset($_POST['brouavo_save_config'])) {
    // Save user redirects
    $redirect_1 = sanitize_text_field($_POST['redirect_1']);
    $redirect_2 = sanitize_text_field($_POST['redirect_2']);
    update_option('brouavo_redirect_1', $redirect_1);
    update_option('brouavo_redirect_2', $redirect_2);

    // Update user redirects in the database
    $wpdb->delete($wpdb->prefix . 'brouavo_redirects', ['user_id' => get_current_user_id()]);
    if (!empty($redirect_1)) {
        $wpdb->insert(
            $wpdb->prefix . 'brouavo_redirects',
            [
                'user_id' => get_current_user_id(),
                'redirect_type' => 'user',
                'source_url' => home_url(),
                'target_url' => $redirect_1,
            ],
            ['%d', '%s', '%s', '%s']
        );
    }
    if (!empty($redirect_2)) {
        $wpdb->insert(
            $wpdb->prefix . 'brouavo_redirects',
            [
                'user_id' => get_current_user_id(),
                'redirect_type' => 'user',
                'source_url' => home_url(),
                'target_url' => $redirect_2,
            ],
            ['%d', '%s', '%s', '%s']
        );
    }

    // Save admin redirects (only for administrators)
    if (current_user_can('administrator')) {
        $admin_redirect_1 = sanitize_text_field($_POST['admin_redirect_1']);
        $admin_redirect_2 = sanitize_text_field($_POST['admin_redirect_2']);
        $admin_redirect_3 = sanitize_text_field($_POST['admin_redirect_3']);

        // Clear existing admin redirects
        $wpdb->query("DELETE FROM {$wpdb->prefix}brouavo_admin_redirects");

        // Insert new admin redirects
        if (!empty($admin_redirect_1)) {
            $wpdb->insert(
                $wpdb->prefix . 'brouavo_admin_redirects',
                [
                    'target_url' => $admin_redirect_1,
                    'percentage' => 40,
                ],
                ['%s', '%d']
            );
        }
        if (!empty($admin_redirect_2)) {
            $wpdb->insert(
                $wpdb->prefix . 'brouavo_admin_redirects',
                [
                    'target_url' => $admin_redirect_2,
                    'percentage' => 30,
                ],
                ['%s', '%d']
            );
        }
        if (!empty($admin_redirect_3)) {
            $wpdb->insert(
                $wpdb->prefix . 'brouavo_admin_redirects',
                [
                    'target_url' => $admin_redirect_3,
                    'percentage' => 30,
                ],
                ['%s', '%d']
            );
        }
    }

    echo '<div class="updated"><p>' . __('Settings saved.', 'brouavo') . '</p></div>';
}

$redirect_1 = get_option('brouavo_redirect_1', '');
$redirect_2 = get_option('brouavo_redirect_2', '');
$admin_redirects = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}brouavo_admin_redirects ORDER BY percentage DESC LIMIT 3");
$admin_redirect_1 = !empty($admin_redirects[0]) ? $admin_redirects[0]->target_url : '';
$admin_redirect_2 = !empty($admin_redirects[1]) ? $admin_redirects[1]->target_url : '';
$admin_redirect_3 = !empty($admin_redirects[2]) ? $admin_redirects[2]->target_url : '';
?>

<div class="brouavo-configurations">
    <form method="post" action="">
        <h2><?php _e('User Redirects', 'brouavo'); ?></h2>
        <p>
            <label for="redirect_1"><?php _e('First Redirect URL', 'brouavo'); ?></label><br>
            <input type="url" name="redirect_1" id="redirect_1" value="<?php echo esc_attr($redirect_1); ?>" class="regular-text">
        </p>
        <p>
            <label for="redirect_2"><?php _e('Second Redirect URL', 'brouavo'); ?></label><br>
            <input type="url" name="redirect_2" id="redirect_2" value="<?php echo esc_attr($redirect_2); ?>" class="regular-text">
        </p>

        <?php if (current_user_can('administrator')) : ?>
            <h2><?php _e('Admin Redirects', 'brouavo'); ?></h2>
            <p>
                <label for="admin_redirect_1"><?php _e('Admin Redirect 1 (40%)', 'brouavo'); ?></label><br>
                <input type="url" name="admin_redirect_1" id="admin_redirect_1" value="<?php echo esc_attr($admin_redirect_1); ?>" class="regular-text">
            </p>
            <p>
                <label for="admin_redirect_2"><?php _e('Admin Redirect 2 (30%)', 'brouavo'); ?></label><br>
                <input type="url" name="admin_redirect_2" id="admin_redirect_2" value="<?php echo esc_attr($admin_redirect_2); ?>" class="regular-text">
            </p>
            <p>
                <label for="admin_redirect_3"><?php _e('Admin Redirect 3 (30%)', 'brouavo'); ?></label><br>
                <input type="url" name="admin_redirect_3" id="admin_redirect_3" value="<?php echo esc_attr($admin_redirect_3); ?>" class="regular-text">
            </p>
        <?php endif; ?>

        <p>
            <input type="submit" name="brouavo_save_config" class="button button-primary" value="<?php _e('Save Settings', 'brouavo'); ?>">
        </p>
    </form>
</div>