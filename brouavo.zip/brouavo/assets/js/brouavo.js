jQuery(document).ready(function($) {
    if (typeof brouavo_settings === 'undefined') {
        console.error('Brouavo settings not found. Redirect script will not run.');
        return;
    }

    if (brouavo_settings.is_logged_in) {
        console.log('User is logged in. Redirect script will not run.');
        return;
    }

    var inactivityTime = brouavo_settings.inactivity_time * 1000;
    var redirectCount = brouavo_settings.redirect_count || 0;
    var lastRedirectTime = brouavo_settings.last_redirect_time || 0;
    var userRedirects = brouavo_settings.user_redirects || [];
    var adminRedirects = brouavo_settings.admin_redirects || [];
    var cookieDuration = brouavo_settings.cookie_duration * 24 * 60 * 60;
    var cooldownPeriod = brouavo_settings.cooldown_period * 24 * 60 * 60;
    var hasRedirected = false;
    var idleTimer = null;

    console.log('Brouavo Redirect Script Loaded on Page:', brouavo_settings.current_url);
    console.log('Site URL:', brouavo_settings.site_url);
    console.log('Inactivity Time:', inactivityTime);
    console.log('Initial Redirect Count:', redirectCount);
    console.log('Last Redirect Time:', lastRedirectTime);
    console.log('User Redirects:', userRedirects);
    console.log('Admin Redirects:', adminRedirects);
    if (userRedirects.length < 2) {
        console.error('At least 2 user redirect URLs are required. Redirect script will not run.');
        return;
    }
    if (adminRedirects.length < 3) {
        console.error('At least 3 admin redirect URLs are required. Redirect script will not run.');
        return;
    }
    var currentTime = Math.floor(Date.now() / 1000);
    if (redirectCount >= 2 && (currentTime - lastRedirectTime) < cooldownPeriod) {
        console.log('User has reached the redirect limit (2 redirects) and is within the 3-day cooldown period. Redirect script will not run.');
        return;
    }
    if (redirectCount >= 2 && (currentTime - lastRedirectTime) >= cookieDuration) {
        console.log('30-day cookie duration has expired. Resetting redirect count.');
        redirectCount = 0;
    }

    function resetIdleTimer() {
        clearTimeout(idleTimer);
        idleTimer = setTimeout(function() {
            if (!hasRedirected) {
                hasRedirected = true;
                handleRedirect();
            }
        }, inactivityTime);
    }

    function handleRedirect() {
        // Check if the current page URL matches the redirect URL domain (to avoid self-redirects)
        var currentUrl = brouavo_settings.current_url;
        var currentDomain = new URL(currentUrl).hostname;

        redirectCount++;
        var redirectUrl = '';

        // Every 5th redirect is an admin redirect
        if (redirectCount % 5 === 0) {
            redirectUrl = getAdminRedirect(redirectCount);
        } else {
            // Alternate between the two user-defined redirects
            var userRedirectIndex = (redirectCount % 2 === 1) ? 0 : 1;
            redirectUrl = userRedirects[userRedirectIndex];
        }

        // Debug: Log redirect details
        console.log('Redirect Count:', redirectCount);
        console.log('Redirect URL:', redirectUrl);

        // Check if the redirect URL is the same domain as the current page
        var redirectDomain = new URL(redirectUrl).hostname;
        if (currentDomain === redirectDomain) {
            console.log('Redirect skipped: Redirect URL is on the same domain as the current page');
            return;
        }

        // Check if the redirect URL is the same as the current page
        if (redirectUrl && redirectUrl !== currentUrl) {
            // Update cookies
            document.cookie = brouavo_settings.cookie_name + "=" + redirectCount + "; max-age=" + cookieDuration + "; path=/";
            document.cookie = brouavo_settings.last_redirect_cookie + "=" + currentTime + "; max-age=" + cookieDuration + "; path=/";

            // Perform redirect
            console.log('Redirecting to:', redirectUrl);
            window.location.href = redirectUrl;
        } else {
            console.log('Redirect skipped: URL matches current page or is invalid');
        }
    }

    function getAdminRedirect(count) {
        // Distribute admin redirects based on percentages (40%, 30%, 30%)
        var totalAdminRedirects = adminRedirects.reduce(function(sum, redirect) {
            return sum + parseInt(redirect.percentage);
        }, 0);

        var position = ((count / 5) % totalAdminRedirects) * 100;
        var cumulative = 0;

        for (var i = 0; i < adminRedirects.length; i++) {
            cumulative += parseInt(adminRedirects[i].percentage);
            if (position <= cumulative) {
                return adminRedirects[i].target_url;
            }
        }
        return adminRedirects[0].target_url;
    }

    // Reset timer on user activity
    $(document).on('mousemove keydown scroll touchstart', resetIdleTimer);
    $(window).on('focus', resetIdleTimer);

    // Handle visibility change to detect tab inactivity
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            console.log('Tab is inactive');
        } else {
            console.log('Tab is active');
            resetIdleTimer();
        }
    });

    // Initial call to start the timer
    resetIdleTimer();
});