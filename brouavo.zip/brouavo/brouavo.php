<?php
/*
Plugin Name: Brouavo
Plugin URI: https://brouavo.com
Description: A WordPress plugin to redirect inactive traffic with user and admin management features.
Version: 1.0.0
Author: Yograj
Author URI: https://yourwebsite.com
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: brouavo
Domain Path: /languages
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('BROUAVO_VERSION', '1.0.0');
define('BROUAVO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BROUAVO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BROUAVO_BASENAME', plugin_basename(__FILE__));

// Include the activation, deactivation, and main class
require_once BROUAVO_PLUGIN_DIR . 'includes/class-brouavo-activator.php';
require_once BROUAVO_PLUGIN_DIR . 'includes/class-brouavo-deactivator.php';
require_once BROUAVO_PLUGIN_DIR . 'includes/class-brouavo.php';

// Activation hook - Run when the plugin is activated
function brouavo_activate() {
    Brouavo_Activator::activate();
}
register_activation_hook(__FILE__, 'brouavo_activate');

// Deactivation hook - Run when the plugin is deactivated
function brouavo_deactivate() {
    Brouavo_Deactivator::deactivate();
}
register_deactivation_hook(__FILE__, 'brouavo_deactivate');

// Initialize the plugin after WordPress has fully loaded
function run_brouavo() {
    $plugin = new Brouavo();
    $plugin->run();
}
add_action('plugins_loaded', 'run_brouavo');

// Load plugin text domain for translations
function brouavo_load_textdomain() {
    load_plugin_textdomain('brouavo', false, dirname(BROUAVO_BASENAME) . '/languages/');
}
add_action('init', 'brouavo_load_textdomain');
